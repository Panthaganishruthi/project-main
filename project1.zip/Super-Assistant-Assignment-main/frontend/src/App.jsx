import Questions from "./components/questions";

const App = () => {

  return (
    <>
      <Questions/>
    </>
  );
};

export default App;
